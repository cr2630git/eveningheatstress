%Combines the calling of various scripts under the Obs_Heat_Analysis umbrella into one handy master script
%(That is, it does all parts after downloading, which still must be done before this)
%Runtime estimates: 
   % about 2 sec per station-year when calculating Tw
   % 20 min per year or 3h15 per decade for the globe when pulling a single variable, e.g. T

%Output is contained in arrays called subdailyt_all, etc


%SETTINGS
%Whether station list already exists or whether we want to create it by
%looking within a particular geographic domain
lookforstns=1; %default is 1
    %if 0, will use an existing outputstnlist but this can be dangerous due
    %to different versions of arrays, so it's usually better to start afresh

if lookforstns==1
    %Where to look for stations
    centrallat=21.7;centrallon=39.15; %degrees; put (0,0) if doing the entire globe; (37, -95) is center of contiguous US
    latint=0.4;lonint=0.4; %distance from center to edge of search box, in degrees; 
        %use 90 and 180 if doing the entire globe, 13 and 30 if doing
        %contiguous US, 0.2 and 0.2 if doing a single station
end

%Stn overall-completeness requirement (eliminate stations with more than this percent of data missing)
%Note however that much of the missing data is toward the beginning of the
    %record (1980s/90s), so analyses focused on recent years can usually allow
    %a maxmissing of 25 or even 50 without a problem
maxmissing=25; %default is 10

%Year and doy range of interest (can be scalars or arrays)
year1=1999;year2=1999;doy1=1;doy2=365; %doy2=366 allows for leap years (but of course non-leap years remain only 365 days)
    %These will be converted to HadISD day numbers using the gethadisddaynumberfromyearanddoy function below
    %If only day numbers are known, run script manually, skipping that
    %part, or convert ahead of time with getyearanddoyfromhadisddaynumber

%Variable(s) of interest
gett=1;gettd=1;computewetbulb=1; %these are default =1
getclouds=0;getprecip=0; %all rest are default =0
getstnlp=0;getslp=0;
getwinddir=0;getwindspd=0;

%How many days to include in the query (0 for 1 day, 1 for three consec. days, 3 for seven consec. days, etc -- anything other than 0 is a special case)
daystogoout=0; %default is 0

%Whether to save results
tosave=0; %default is 0; REQUIRES MANUAL EDITING FOR FULL FUNCTIONALITY
%%%



icloud='~/Library/Mobile Documents/com~apple~CloudDocs/';
rawstndatadir='/Volumes/ExtDriveC/HadISD_thru2023/';
metadatadir=strcat(icloud,'General_Academics/Research/Obs_Heat_Analysis/');
saveloc=strcat(metadatadir,'More_Station_Output/');
saveloc_ext='/Volumes/ExternalDriveZ/Obs_Heat_Analysis/';
slp=1013; %mb


%%%EVERYTHING BELOW HERE SHOULD RUN AUTOMATICALLY%%%


yeartmp=[year1:year2]';doytmp=[doy1:doy2]';

yeararr=[];doyarr=[];
for y=1:length(yeartmp)
    if rem(yeartmp(y),4)==0;ylen=366;else;ylen=365;end

    if doy2==366 && doy1==1 %i.e. get a full year and allow for leap years too
        yeararr=[yeararr;yeartmp(y).*ones(ylen,1)];
        doyarr=[doyarr;[1:ylen]'];
    else %all other cases
        yeararr=[yeararr;yeartmp(y).*ones(doy2-doy1+1,1)];
        doyarr=[doyarr;doytmp];
    end
end


%Load metadata
exist finalstnmetadata;
if ans==0
    finalstnmetadata=load(strcat(metadatadir,'combinedmetadata_4422stns.mat'));
    finalstnlatlon=finalstnmetadata.finalstnlatlon;finalstnnames=finalstnmetadata.finalstnnames;
    finalstnelev=finalstnmetadata.finalstnelev;finalstncodes=finalstnmetadata.finalstncodes;finalstnlist=finalstnmetadata.finalstnlist;
end


%Find stations in a given rectangular region that meet data availability
%requirements (and which already met the quality requirements of Raymond et al. 2020) 
%OR
%Use existing station list
if lookforstns==1
    stationdatafinder_4422stns;
end
numstns=length(outputstnlist);

%Get HadISD day info (specific to what's in the saved arrays)
d=NaN.*ones(size(yeararr,1),1);
for i=1:size(yeararr,1)
    d(i,1)=gethadisddaynumberfromyearanddoy(yeararr(i),doyarr(i));
end
numdays=size(d,1);


%Get subdaily data arrays
%Downloaded from 2024-01-01 HadISD edition
clear stninfo;clear stnnames;
clear subdailytimes_all;clear subdailyt_all;clear subdailytd_all;clear subdailyrh_all;clear subdailytw_all;
clear subdailyclouds_all;clear subdailywinddir_all;clear subdailywindspd_all;clear subdailyprecip1hr_all;
subdailytimes_all=NaN.*ones(numstns,numdays,24);
if gett==1;subdailyt_all=NaN.*ones(numstns,numdays,24);end
if gettd==1;subdailytd_all=NaN.*ones(numstns,numdays,24);end
if computewetbulb==1;subdailyrh_all=NaN.*ones(numstns,numdays,24);subdailytw_all=NaN.*ones(numstns,numdays,24);end
if getclouds==1;subdailyclouds_all=NaN.*ones(numstns,numdays,24);end
if getwinddir==1;subdailywinddir_all=NaN.*ones(numstns,numdays,24);end
if getwindspd==1;subdailywindspd_all=NaN.*ones(numstns,numdays,24);end
if getprecip==1;subdailyprecip1hr_all=NaN.*ones(numstns,numdays,24);end
for stn=1:numstns
    s=outputstnlist(stn);
    stncode_part1=str2num(finalstncodes(s,1:6));
    edition='2023f_19310101-20240101';

    thisfilename=strcat(rawstndatadir,'hadisd.3.4.0.',edition,'_',finalstncodes(s,:),'.nc');
    if exist(thisfilename,'file')==2
        %Get station metadata
        stninfo(stn,1:2)=finalstnlatlon(s,:);
        stninfo(stn,3)=finalstnelev(s);
        stnnames{stn,1}=finalstnnames{s};

        %Get variables for this station
        time=ncread(thisfilename,'time'); %contains hours since 1/1/1931
        if gett==1
            temperature=ncread(thisfilename,'temperatures');
            invalid=abs(temperature)>60;temperature(invalid)=NaN;
        end
        if gettd==1
            dewpoint=ncread(thisfilename,'dewpoints');
            invalid=abs(dewpoint)>40;dewpoint(invalid)=NaN;
        end
        if getclouds==1;clouds=ncread(thisfilename,'total_cloud_cover');end
        if getslp==1;slp=ncread(thisfilename,'slp');end
        if getstnlp==1;stnlp=ncread(thisfilename,'stnlp');end
        if getprecip==1;precip1hr=ncread(thisfilename,'precip1_depth');end
        if getwinddir==1;winddir=ncread(thisfilename,'winddirs');end
        if getwindspd==1;windspd=ncread(thisfilename,'windspeeds');end
        if gettd==1;relhum=calcrhfromTandTd(temperature,dewpoint);end

        %Compute wet-bulb temperature
        if computewetbulb==1
            q=calcqfromTd(dewpoint)./1000;
            pres=pressurefromelev(finalstnelev(s)).*slp./1000.*100.*ones(size(temperature,1),size(temperature,2),size(temperature,3));
            %pres=stnlp.*100.*ones(size(temperature,1),size(temperature,2),size(temperature,3));
                %Not enough stations have regular stnlp measurements for this
                %to be a generally recommended method
            wetbulb=calcwbt_daviesjones(temperature,pres,q,0); %Davies-Jones method
        end

        %Narrow down to specific days of interest
        for i=1:numdays
            firsthourtoplot=(d(i)-daystogoout)*24-23;lasthourtoplot=(d(i)+daystogoout)*24;
    
            timestopick=time(:,1)>=firsthourtoplot & time(:,1)<=lasthourtoplot;

            timespresent=time(timestopick);
            timespresent_124=timespresent-firsthourtoplot+1; %as hour of day
    
            %Also create versions that have no gaps by filling in missing values with NaN
            subdailytimes_all(stn,i,timespresent_124)=timespresent;
            if gett==1;subdailyt_all(stn,i,timespresent_124)=temperature(timestopick);end
            if gettd==1;subdailytd_all(stn,i,timespresent_124)=dewpoint(timestopick);end
            if getclouds==1;subdailyclouds_all(stn,i,timespresent_124)=clouds(timestopick);end
            if getprecip==1;subdailyprecip1hr_all(stn,i,timespresent_124)=precip1hr(timestopick);end
            if getwinddir==1;subdailywinddir_all(stn,i,timespresent_124)=winddir(timestopick);end
            if getwindspd==1;subdailywindspd_all(stn,i,timespresent_124)=windspd(timestopick);end
            if computewetbulb==1;subdailyrh_all(stn,i,timespresent_124)=relhum(timestopick);...
                    subdailytw_all(stn,i,timespresent_124)=wetbulb(timestopick);end
        end

        subdailytimes_all=squeeze(subdailytimes_all);
        if gett==1;subdailyt_all=squeeze(subdailyt_all);end
        if gettd==1;subdailytd_all=squeeze(subdailytd_all);end
        if getclouds==1;subdailyclouds_all=squeeze(subdailyclouds_all);end
        if getprecip==1;subdailyprecip1hr_all=squeeze(subdailyprecip1hr_all);end
        if getwinddir==1;subdailywinddir_all=squeeze(subdailywinddir_all);end
        if getwindspd==1;subdailywindspd_all=squeeze(subdailywindspd_all);end
        if computewetbulb==1;subdailyrh_all=squeeze(subdailyrh_all);subdailytw_all=squeeze(subdailytw_all);end

        if computewetbulb==1;invalid=subdailytw_all>40;subdailytw_all(invalid)=NaN;end
        if gett==1;invalid=subdailyt_all>60;subdailyt_all(invalid)=NaN;end
        if gettd==1;invalid=subdailytd_all>40;subdailytd_all(invalid)=NaN;end
        if computewetbulb==1;invalid=subdailyrh_all>120;subdailyrh_all(invalid)=NaN;invalid=subdailyrh_all<0;subdailyrh_all(invalid)=NaN;end
    end
    if computewetbulb==1;outputcadence=20;else;outputcadence=200;end %because wet-bulb calculation is much slower
    if rem(stn,outputcadence)==0;fprintf('In completestndataanalysis, have just done stn %d of %d\n',stn,numstns);end
end
dates_all=[yeararr doyarr];
clear invalid;

%Whether to save
%IF SO, REQUIRES MANUAL EDITING FOR FULL FUNCTIONALITY
if tosave==1
    %Saving to csv file
    %for stn=1:numstns
    %    arr=round2(squeeze(subdailytw_all(stn,:,:)),0.1);
    %    if stninfo(stn,1)>0;latletter='N';else;latletter='S';end
    %    if stninfo(stn,2)>0;lonletter='E';else;lonletter='W';end
    %    writematrix(arr,strcat(saveloc,'lat',num2str(abs(round2(stninfo(stn,1),0.01)*100)),latletter,...
    %        'lon',num2str(abs(round2(stninfo(stn,2),0.01)*100)),lonletter,'_tw_',num2str(yeararr(1)),'.csv'));
    %end

    %Saving to mat file (example)
    %fname='subdailyt_globe_1990-1999';
    fname='usdata_1931-2022';
    save(strcat(saveloc_ext,fname),'subdailyt_all','subdailytimes_all','stninfo','dates_all');
end
