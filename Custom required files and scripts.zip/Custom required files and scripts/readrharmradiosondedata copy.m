function readrharmradiosondedata(rharmdir,savedir,savefilename,goallevs,vnames,numyrs,startyr,stopyr,arraystartyr)
%Read RHARM radiosonde data and clean it up, interpolating to desired pressure levels (goallevs)
%Variables read are temperature, RH, wind speed, wind direction
%Note: startyr and stopyr are the years between which data is read; 
%numyrs starts counting with arraystartyr and controls size of array, 
    %so e.g. if another array is being matched and some blank years are needed, numyrs will not = (stopyr-startyr+1)

latlist=[];lonlist=[];
nl=length(goallevs);

tdata=NaN.*ones(1,numyrs,12,30,2,nl);rhdata=NaN.*ones(1,numyrs,12,30,2,nl); %dims are stn | year | month | day of month | hour of day (00 or 12 UTC) | pressure level
windspddata=NaN.*ones(1,numyrs,12,30,2,nl);winddirdata=NaN.*ones(1,numyrs,12,30,2,nl);


for y=startyr:stopyr
    for m=1:12
        %Read data for this month
        if m<=9;zm='0';else;zm='';end
        fname=strcat(rharmdir,'IGRA_H_',num2str(y),zm,num2str(m),'01_',num2str(y),zm,num2str(m),'30_global_cdm-lev_v1.csv');
        opts=detectImportOptions(fname);
        opts.VariableNames=vnames;opts.VariableNamesLine=23;opts.Delimiter=',';

        data=readtable(fname,opts);

        %Set up dates
        alltheselats=data(:,8).latitude;alltheselons=data(:,7).longitude;
        if iscell(alltheselats)
            alltheselats=str2double(alltheselats);alltheselons=str2double(alltheselons);
        end
        
        tmp=data(:,5).actual_time;
        allthesedoms=NaN.*ones(length(tmp),1);for i=1:length(tmp);allthesedoms(i)=str2num(tmp{i}(9:10));end
        allthesehods=NaN.*ones(length(tmp),1);for i=1:length(tmp);allthesehods(i)=str2num(tmp{i}(12:13));end;clear tmp;

        %Read T, P, RH, and wind, converting units and formats as necessary
        allthesetemps=data(:,11).air_temperature;
        allthesepressures=data(:,10).air_pressure;
        alltheserhs=data(:,13).relative_humidity; %percent
        allthesewindspds=data(:,15).wind_speed;
        allthesewinddirs=data(:,16).wind_from_direction;
        if iscell(allthesetemps)
            allthesetemps=str2double(allthesetemps);allthesepressures=str2double(allthesepressures);alltheserhs=str2double(alltheserhs);
            allthesewinddirs=str2double(allthesewinddirs);allthesewindspds=str2double(allthesewindspds);
        end
        allthesetemps=allthesetemps-273.15; %C
        allthesepressures=allthesepressures./100; %mb

        %Organize data by stations
        row=2;stnfirstrow=1;
        while row<=size(data,1)
            thislat=alltheselats(row);thislon=alltheselons(row);
            prevlat=alltheselats(row-1);prevlon=alltheselons(row-1);

            %Keep going until the end of this station is reached
            if thislat~=prevlat && thislon~=prevlon %am on first row of next station
                stnlastrow=row-1;
                thisdom=allthesedoms(stnlastrow);
                thishod=allthesehods(stnlastrow);
                if thishod==0 || thishod==23 || thishod==1
                    hodi=1;
                elseif thishod==11 || thishod==12 || thishod==13
                    hodi=2;
                else
                    hodi=NaN;
                end
            
                %Check for station in list of what we already have; if it's not there, add it
                thisord=0;
                if isempty(latlist)==1
                    latlist=thislat;lonlist=thislon;thisord=1;
                else
                    found=0;
                    tocheck=1;
                    while tocheck<=length(latlist) && found==0
                        if abs(latlist(tocheck)-prevlat)<0.01 && abs(lonlist(tocheck)-prevlon)<0.01 %found where data for this stn lives
                            thisord=tocheck;found=1;
                        end
                        tocheck=tocheck+1;
                    end
                    if thisord==0;latlist=[latlist;prevlat];lonlist=[lonlist;prevlon];thisord=length(latlist);end
                end

                %For troubleshooting: stop if on a specific station
                %if abs(prevlat-39.072)<0.01 && abs(prevlon+95.631)<0.01 && m==7;disp('found stn');return;end

                %Interpolate data to standard pressure levels
                %Do this by getting data for each goal level, interpolating as needed
                tdataraw=allthesetemps(stnfirstrow:stnlastrow); %C
                pdataraw=allthesepressures(stnfirstrow:stnlastrow); %mb
                rhdataraw=alltheserhs(stnfirstrow:stnlastrow); %percent
                windspddataraw=allthesewindspds(stnfirstrow:stnlastrow);
                winddirdataraw=allthesewinddirs(stnfirstrow:stnlastrow);

                if iscell(tdataraw);tdataraw=str2double(tdataraw);end
                if iscell(pdataraw);pdataraw=str2double(pdataraw);end
                if iscell(rhdataraw);rhdataraw=str2double(rhdataraw);end
                if iscell(windspddataraw);windspddataraw=str2double(windspddataraw);end
                if iscell(winddirdataraw);winddirdataraw=str2double(winddirdataraw);end
                
                cleanp=NaN.*ones(nl,1);cleant=NaN.*ones(nl,1);cleanrh=NaN.*ones(nl,1);cleanwindspd=NaN.*ones(nl,1);cleanwinddir=NaN.*ones(nl,1);
                for i=1:nl
                    thisgoal=goallevs(i);
                    %Now, move through pressure vector until two values that bracket this goallev are found (until one of them already is a goallev itself)
                    for j=1:length(pdataraw)
                        if pdataraw(j)==thisgoal
                            cleanp(i)=pdataraw(j);
                            cleant(i)=tdataraw(j);
                            cleanrh(i)=rhdataraw(j);
                            cleanwindspd(i)=windspddataraw(j);
                            cleanwinddir(i)=winddirdataraw(j);
                        elseif j>=2
                            if pdataraw(j)>thisgoal && pdataraw(j-1)<thisgoal
                                difffromabove=thisgoal-pdataraw(j-1);
                                difffrombelow=pdataraw(j)-thisgoal;
                                belowweight=difffromabove/(difffrombelow+difffromabove);
                                aboveweight=1-belowweight;

                                cleanp(i)=pdataraw(j)*belowweight+pdataraw(j-1)*aboveweight;
                                cleant(i)=tdataraw(j)*belowweight+tdataraw(j-1)*aboveweight;
                                cleanrh(i)=rhdataraw(j)*belowweight+rhdataraw(j-1)*aboveweight;
                                cleanwindspd(i)=windspddataraw(j)*belowweight+windspddataraw(j-1)*aboveweight;
                                cleanwinddir(i)=winddirdataraw(j)*belowweight+winddirdataraw(j-1)*aboveweight;
                            end
                        end
                    end
                end

                %Slot in data for this station, year, month, and set of pressure levels
                if ~isnan(hodi) %i.e. data is at an hour we want
                    tdata(thisord,y-(arraystartyr-1),m,thisdom,hodi,:)=cleant;
                    rhdata(thisord,y-(arraystartyr-1),m,thisdom,hodi,:)=cleanrh;
                    windspddata(thisord,y-(arraystartyr-1),m,thisdom,hodi,:)=cleanwindspd;
                    winddirdata(thisord,y-(arraystartyr-1),m,thisdom,hodi,:)=cleanwinddir;
                end

                %Reset station row marker for next station
                stnfirstrow=row;
            end
            row=row+1;
        end
    end
    disp(y);disp(clock);
end

invalid=tdata==0;tdata(invalid)=NaN;
invalid=rhdata==0;rhdata(invalid)=NaN;
invalid=windspddata==0;windspddata(invalid)=NaN;
invalid=winddirdata==0;winddirdata(invalid)=NaN;
invalid=abs(lonlist)>180;latlist(invalid)=NaN;lonlist(invalid)=NaN;
tdata_rharm=tdata;rhdata_rharm=rhdata;windspddata_rharm=windspddata;winddirdata_rharm=winddirdata;
latlist_rharm=latlist;lonlist_rharm=lonlist;
save(strcat(savedir,savefilename),'tdata_rharm','rhdata_rharm','windspddata_rharm','winddirdata_rharm','latlist_rharm','lonlist_rharm','-append');


%Convert RH to q (1 min)
pdata=permute(repmat(goallevs.*100,[1 size(tdata,1) size(tdata,2) size(tdata,3) size(tdata,4) size(tdata,5)]),[2 3 4 5 6 1]);
qdata_rharm=calcqfromTd_dynamicP(calcTdfromTandrh(tdata,rhdata),pdata);



%Get monthly means, with necessary conditions on data availability
%For a station-month to be valid, it must have 50% of hours available
%Do a pre-screening to determine which stations have reasonable amounts of data for both 00 and 12
    %UTC, and which have only one or the other (based on 300-mb level so elevation is not a factor)
%Use 00 UTC if it qualifies; if not, try using 12 UTC
monthlyqmeans=NaN.*ones(size(tdata,1),size(tdata,2),size(tdata,3),nl);
q_annualmean_rharmstns=NaN.*ones(size(tdata,1),nl,size(tdata,2));
clear thismonfracvalid;
for stn=1:size(tdata,1)
    frac00avail(stn)=sum(sum(sum(~isnan(qdata_rharm(stn,:,:,:,1,2)))))./((stopyr-startyr+1)*12*30); %total number of days of data (approx.)
    frac12avail(stn)=sum(sum(sum(~isnan(qdata_rharm(stn,:,:,:,2,2)))))./((stopyr-startyr+1)*12*30);

    if frac00avail(stn)>=0.33
        for y=1:size(tdata,2)
            for m=1:size(tdata,3)
                for lev=1:nl
                    thismonfracvalid(stn,y,m,lev)=sum(~isnan(qdata_rharm(stn,y,m,:,1,lev)))./30;
                    if thismonfracvalid(stn,y,m,lev)>=0.50 %proceed to get monthly mean
                        monthlyqmeans(stn,y,m,lev)=mean(qdata_rharm(stn,y,m,:,1,lev),'omitnan');
                    end
                end
            end
        end
    elseif frac12avail(stn)>=0.33
        for y=1:size(tdata,2)
            for m=1:size(tdata,3)
                for lev=1:nl
                    thismonfracvalid(stn,y,m,lev)=sum(~isnan(qdata_rharm(stn,y,m,:,2,lev)))./30;
                    if thismonfracvalid(stn,y,m,lev)>=0.50 %proceed to get monthly mean
                        monthlyqmeans(stn,y,m,lev)=mean(qdata_rharm(stn,y,m,:,2,lev),'omitnan');
                    end
                end
            end
        end
    end

    %Now, get annual means, requiring at least 9 of 12 months be present in each year
    for y=1:size(tdata,2)
        for lev=1:nl
            tmp=squeeze(monthlyqmeans(stn,y,:,lev));
            if sum(~isnan(tmp))>=9
                q_annualmean_rharmstns(stn,lev,y)=mean(tmp,'omitnan');
            end
        end
    end

    %To increase data availability, consolidate annual means to 5-year means
    for lev=1:nl
        for y=5:5:size(tdata,2)
            q_5yrmean_rharmstns(stn,lev,y/5)=mean(squeeze(q_annualmean_rharmstns(stn,lev,y-4:y)),'omitnan')./1000; %kg/kg
        end
    end

    %Get trends at each station
    for lev=1:nl
        %p=polyfit(x(11:45),squeeze(q_annualmean_rharmstns(stn,lev,11:45)),1);q_annualmeanslopes_rharmstns_19802014(stn,lev)=p(1);
        p=polyfit(3:9,squeeze(q_5yrmean_rharmstns(stn,lev,3:9)),1);q_5yrmeanslopes_rharmstns_19802014(stn,lev)=p(1);
    end
end
q_annualmean_rharmstns=flip(q_annualmean_rharmstns,2); %so lowest level is in position 1 of second dimension
q_5yrmean_rharmstns=flip(q_5yrmean_rharmstns,2);
q_5yrmeanslopes_rharmstns_19802014=flip(q_5yrmeanslopes_rharmstns_19802014,2);


save(strcat(savedir,savefilename),'q_annualmean_rharmstns','q_5yrmean_rharmstns','q_5yrmeanslopes_rharmstns_19802014','-append');

end