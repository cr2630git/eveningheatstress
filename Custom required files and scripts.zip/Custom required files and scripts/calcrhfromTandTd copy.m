function rh = calcrhfromTandTd(T,Td)
%Calculate RH from T and Td (both in deg C)
%Uses formula listed at http://andrew.rsmas.miami.edu/bmcnoldy/Humidity.html

rh=100.*(exp((17.625.*Td)./(243.04+Td))./exp((17.625.*T)./(243.04+T)));

end

