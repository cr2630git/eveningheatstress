%Finds best stations in a given rectangular region by looking into station data availability and quality

%Inputs: centrallat, latint, centrallon, lonint, maxmissing (in %)
%Requires ExternalDriveZ

minlat=centrallat-latint;maxlat=centrallat+latint;
minlon=centrallon-lonint;maxlon=centrallon+lonint; %minlon is west, maxlon is east

stns=load('/Volumes/ExternalDriveZ/Obs_Heat_Analysis/combinedmetadata_4422stns.mat');
lats=stns.combinedstnlats;lons=stns.combinedstnlons;

stnlist=[];c=0;
for i=1:length(lats);if lats(i)>=minlat && lats(i)<=maxlat && lons(i)>=minlon && lons(i)<=maxlon;c=c+1;stnlist(c,1)=i;end;end


exist twarray;
if ans==0
    finalarrays=load('/Volumes/ExternalDriveZ/Obs_Heat_Analysis/combinedarrays_4422stns.mat');
    twarray=finalarrays.twarray;
end

%Eliminate stations with too much data missing
newc=0;outputstnlist=[];
startday=17533; %default is 17533, i.e. 1979/01/01
for i=1:size(stnlist,1)
    temp=squeeze(twarray(stnlist(i),startday:size(twarray,2),3));
    if sum(isnan(temp))/(size(twarray,2)-startday)<=maxmissing/100
        newc=newc+1;
        outputstnlist(newc)=stnlist(i);
    end
end


%List of latitudes and longitudes for good stns
%fs(outputstnlist,:);


%Trial-and-error code snippets
dothis=0;
if dothis==1
figure(1);subplot(2,1,1);plot(fs(outputstnlist,1));
subplot(2,1,2);plot(fs(outputstnlist,2));


plot(squeeze(twarray(outputstnlist(1),17533:size(twarray,2),3)));
end






