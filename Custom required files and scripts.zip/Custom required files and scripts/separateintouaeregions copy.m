function outputreg = separateintouaeregions(mylat,mylon,lat_era5,lon_era5,lsmask_era5,lsmaskval,uaelats,uaelons)
%Based on a point's lat/lon, decides whether it belongs in coastal waters
    %(within 50 km of mainland UAE coast); coastal land (within 50 km of
    %Persian Gulf); or inland (all other UAE >100 km from water and west of 55.8E [to exclude higher
    %terrain near Ras al-Khaimah])

    %Runtime: about 1 min at 0.25-deg resolution
    outputreg=NaN;

    if mylon<=56.5 && mylon>=51.5 && mylat>=22.5 && mylat<=26.4

        mainlanduaecoastlats=[24.38;24.26;24.03;24.03;24.21;24.13;24.28;24.24;24.84;25.04;25.36;25.63;25.74];
        mainlanduaecoastlons=[51.59;51.78;51.85;52.34;52.60;53.57;53.83;53.97;54.73;55.00;55.29;55.61;55.8];
        for i=1:length(mainlanduaecoastlats)-1
            coastlats(i*100-99:i*100)=linspace(mainlanduaecoastlats(i),mainlanduaecoastlats(i+1),100);
            coastlons(i*100-99:i*100)=linspace(mainlanduaecoastlons(i),mainlanduaecoastlons(i+1),100);
        end

        if inpolygon(mylat,mylon,uaelats,uaelons)==1 %land in UAE

            %Search for dist to closest water
            mindistsofar=1000;keepgoing=1;
            for minii=1:size(lat_era5,1)
                for minij=1:size(lon_era5,2)
                    testlat=lat_era5(minii,minij);testlon=lon_era5(minii,minij);
                    if testlat<=26.4 && testlat>=22.5 && testlon<=56.5 && testlon>=51.5 %is calculating precise distance even worth it?
                        if lsmask_era5(minii,minij)<=0.5 %test point is water
                            if keepgoing==1
                                mydist=distance(mylat,mylon,testlat,testlon)*111;
                                if mydist<mindistsofar
                                    mindistsofar=mydist;
    
                                    if mindistsofar<=50 %one close water point suffices -- don't need to search any more
                                        keepgoing=0;
                                    end
                                end
                            end
                        end
                    end
                end
            end

            if mindistsofar<=50
                outputreg=2; %coastal land
            elseif mindistsofar>100 %inland UAE
                outputreg=3; %inland
            end
        elseif lsmaskval<=0.5 %water, so calculate distance to mainland UAE coast
            ptisnearland=0;mindistsofar=1000;keepgoing=1;
            for testi=1:length(coastlats)
                testlat=coastlats(testi);testlon=coastlons(testi);
                if mylat<=26.4 && mylat>=22.5 && mylon<=56.5 && mylon>=51.5 %is calculating precise distance even worth it?
                    if keepgoing==1
                        mydist=distance(mylat,mylon,testlat,testlon)*111;
                        if mydist<mindistsofar
                            mindistsofar=mydist;
    
                            if mindistsofar<=50 %coastal water
                                ptisnearland=1;keepgoing=0;
                            end
                        end
                    end
                end
            end
            if ptisnearland==1
                outputreg=1; %coastal water
            end
        end
    end
end

