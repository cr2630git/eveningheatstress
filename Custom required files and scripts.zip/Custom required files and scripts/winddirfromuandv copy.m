function winddir = winddirfromuandv(u,v)
%Given u and v, calculates the meteorological wind direction (with 90 as a
%wind from the east and 270 as a wind from the west)

winddir=atan2d(u,v)+180;


end

