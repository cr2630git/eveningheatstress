%Describes and implements (part #1 of) Matlab portion of procedure for quickly computing
%Davies-Jones adiabatic wet-bulb temperature

%%%%The actual calculation is done in Python for efficiency and needs to be executed manually (see Code Block 2 below)%%%%

%Note: arrt (2-m temperature) in C, arrq (2-m specific humidity) in g/kg, arrp (surface pressure) in Pa
%Each array needs to have time as final dimension

%arrt -- temperature array
%arrq -- specific-humidity array
%arrp -- surface-pressure array

%suffixforfilename is default '', or can be a year e.g. '_2021', or an ensemble member e.g. '_mem10'


%Code Block 1 (runtime 20 sec per 10^9 values)
%---------------
%Exports necessary variables to netcdf files
%If total size is too large, splits them into smaller chunks
if ndims(arrt)==2
    s1=size(arrt,1);arrdims=2;
    nontimesz=s1;timesz=size(arrt,2);
elseif ndims(arrt)==3
    s1=size(arrt,1);s2=size(arrt,2);arrdims=3;
    nontimesz=s1*s2;timesz=size(arrt,3);
elseif ndims(arrt)==4
    s1=size(arrt,1);s2=size(arrt,2);s3=size(arrt,3);arrdims=4;
    nontimesz=s1*s2*s3;timesz=size(arrt,4);
end

expectedtime=round2(60*numel(arrt)/10^9,10);
%disp(strcat(['Expected time is ',num2str(expectedtime),' seconds']));
if numel(arrt)>=250*10^6 %need to split
    %Go through factors of timesz to find an appropriate chunk size
    %Haven't yet dealt with case where timesz is prime
    divs=divisors(timesz);continueon=1;
    for myidx=length(divs):-1:1
        thisdiv=divs(myidx);
        if nontimesz*thisdiv<=250*10^6 && continueon==1 %choose this divisor
            chunksz=thisdiv;continueon=0;
        end
    end
    numchunks=timesz/chunksz;
else %can do it all in one go
    numchunks=1;chunksz=timesz;
end

for chunknum=1:numchunks
    indstart=chunksz*chunknum-(chunksz-1);indstop=chunksz*chunknum;
    exporttonetcdf_forwetbulbcalc(arrt,arrq,arrp,indstart,indstop,chunknum,suffixforfilename);
end

clear arrt;clear arrp;clear arrq;
disp('Finished block 1 of calctw_matlabpythonhelper_part1.m');
%---------------


%Code Block 2 (runtime 4 min per 10^9 values)
%%%%---------------
%In a Jupyter notebook, run final cell of speedywetbulb_copy.ipynb [in home directory for ease of access] which reads the
    %saved values, compute DJ wet-bulb temperature, and save to another netcdf file
%%%%---------------


%Then, run calctw_matlabpythonhelper_part2.m

