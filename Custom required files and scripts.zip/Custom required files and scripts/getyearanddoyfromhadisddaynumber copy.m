function [year,doy] = getyearanddoyfromhadisddaynumber(daynumber)
%Gets HadISD day number from any year/day combination
%  This is based on HadISD data starting 1/1/1931

clear year;clear doy;
for ord=1:length(daynumber)
    %First, find year
    yearstotry=1932:2030;
    for i=1:length(yearstotry)
        yr=yearstotry(i);
        if abs(DaysApart(12,31,1930,1,1,yr)-daynumber(ord))<abs(DaysApart(12,31,1930,1,1,yr-1)-daynumber(ord)) && ...
                daynumber(ord)-DaysApart(12,31,1930,1,1,yr)>=0 %found the right year
            theyear=yr;
        end
    end
    
    %Now, find month and day
    %Just brute-force it by going through all the days of the year
    for doyord=1:366
        mon=DOYtoMonth(doyord,theyear);dom=DOYtoDOM(doyord,theyear);
        if DaysApart(12,31,1930,mon,dom,theyear)==daynumber(ord)
            themonth=mon;thedom=dom;thedoy=doyord;
        end
    end
    
    year(ord)=theyear;
    doy(ord)=thedoy;
end

end