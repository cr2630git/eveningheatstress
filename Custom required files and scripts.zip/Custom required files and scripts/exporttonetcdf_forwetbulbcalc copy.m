function exporttonetcdf_forwetbulbcalc(arrt,arrq,arrp,indstart,indstop,chunknum,yearforfilename)
%Saves variables to netcdf files so that they can be read into Python and
%wet-bulb temperature speedily computed
%   It would be preferable to run the Python code directly from Matlab but
%   there seem to be some compatibility issues with pyrunfile that prevent
%   this from being straightforward

%yearforfilename is default '' or can be e.g. '_2021'


%Input arrays must have time as final dimension
if ndims(arrt)==2 %dims are something | time
    dim1sz=size(arrt,1);chunksz=indstop-indstart+1;

    t_thischunk=squeeze(arrt(:,indstart:indstop));
    nccreate(strcat('/Users/craymond/t2m_chunk',num2str(chunknum),yearforfilename,'.nc'),'t2m','Dimensions',{'lon',dim1sz,'time',chunksz});
    ncwrite(strcat('/Users/craymond/t2m_chunk',num2str(chunknum),yearforfilename,'.nc'),'t2m',t_thischunk);clear t_thischunk;
    
    q_thischunk=squeeze(arrq(:,indstart:indstop));
    nccreate(strcat('/Users/craymond/q2m_chunk',num2str(chunknum),yearforfilename,'.nc'),'q2m','Dimensions',{'lon',dim1sz,'time',chunksz});
    ncwrite(strcat('/Users/craymond/q2m_chunk',num2str(chunknum),yearforfilename,'.nc'),'q2m',q_thischunk);clear q_thischunk;
    
    p_thischunk=squeeze(arrp(:,indstart:indstop));
    nccreate(strcat('/Users/craymond/psfc_chunk',num2str(chunknum),yearforfilename,'.nc'),'psfc','Dimensions',{'lon',dim1sz,'time',chunksz});
    ncwrite(strcat('/Users/craymond/psfc_chunk',num2str(chunknum),yearforfilename,'.nc'),'psfc',p_thischunk);clear p_thischunk;
elseif ndims(arrt)==3 %dims are usually lat | lon | time
    dim1sz=size(arrt,1);dim2sz=size(arrt,2);chunksz=indstop-indstart+1;

    t_thischunk=squeeze(arrt(:,:,indstart:indstop));
    nccreate(strcat('/Users/craymond/t2m_chunk',num2str(chunknum),yearforfilename,'.nc'),'t2m','Dimensions',{'lon',dim1sz,'lat',dim2sz,'time',chunksz});
    ncwrite(strcat('/Users/craymond/t2m_chunk',num2str(chunknum),yearforfilename,'.nc'),'t2m',t_thischunk);clear t_thischunk;
    
    q_thischunk=squeeze(arrq(:,:,indstart:indstop));
    nccreate(strcat('/Users/craymond/q2m_chunk',num2str(chunknum),yearforfilename,'.nc'),'q2m','Dimensions',{'lon',dim1sz,'lat',dim2sz,'time',chunksz});
    ncwrite(strcat('/Users/craymond/q2m_chunk',num2str(chunknum),yearforfilename,'.nc'),'q2m',q_thischunk);clear q_thischunk;
    
    p_thischunk=squeeze(arrp(:,:,indstart:indstop));
    nccreate(strcat('/Users/craymond/psfc_chunk',num2str(chunknum),yearforfilename,'.nc'),'psfc','Dimensions',{'lon',dim1sz,'lat',dim2sz,'time',chunksz});
    ncwrite(strcat('/Users/craymond/psfc_chunk',num2str(chunknum),yearforfilename,'.nc'),'psfc',p_thischunk);clear p_thischunk;
elseif ndims(arrt)==4 %dims are usually lat | lon | level | time
    %Note that values do not have to be 2m, but are named this just for simplicity/consistency
    dim1sz=size(arrt,1);dim2sz=size(arrt,2);dim3sz=size(arrt,3);chunksz=indstop-indstart+1;

    t_thischunk=squeeze(arrt(:,:,:,indstart:indstop));
    nccreate(strcat('/Users/craymond/t2m_chunk',num2str(chunknum),yearforfilename,'.nc'),'t2m','Dimensions',{'lon',dim1sz,'lat',dim2sz,'lev',dim3sz,'time',chunksz});
    ncwrite(strcat('/Users/craymond/t2m_chunk',num2str(chunknum),yearforfilename,'.nc'),'t2m',t_thischunk);clear t_thischunk;
    
    q_thischunk=squeeze(arrq(:,:,:,indstart:indstop));
    nccreate(strcat('/Users/craymond/q2m_chunk',num2str(chunknum),yearforfilename,'.nc'),'q2m','Dimensions',{'lon',dim1sz,'lat',dim2sz,'lev',dim3sz,'time',chunksz});
    ncwrite(strcat('/Users/craymond/q2m_chunk',num2str(chunknum),yearforfilename,'.nc'),'q2m',q_thischunk);clear q_thischunk;
    
    p_thischunk=squeeze(arrp(:,:,:,indstart:indstop));
    nccreate(strcat('/Users/craymond/psfc_chunk',num2str(chunknum),yearforfilename,'.nc'),'psfc','Dimensions',{'lon',dim1sz,'lat',dim2sz,'lev',dim3sz,'time',chunksz});
    ncwrite(strcat('/Users/craymond/psfc_chunk',num2str(chunknum),yearforfilename,'.nc'),'psfc',p_thischunk);clear p_thischunk;
else
    disp('Have not yet accounted for an array of this size in exporttonetcdf_forwetbulbcalc!');return;
end

end