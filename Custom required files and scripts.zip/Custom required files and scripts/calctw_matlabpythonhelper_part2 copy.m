%Describes and implements (part #2 of) Matlab portion of procedure for quickly computing
%Davies-Jones adiabatic wet-bulb temperature
%The actual calculation is done in Python for efficiency
%Procedure: first run calctw_matlabpythonhelper_part1, including Python code as noted there; then, run this script

%Ensure variables are properly set or carried through from calctw_matlabpythonhelper_part1:
%suffixforfilename, chunksz, numchunks, arrdims, s1, (s2, s3), timesz
%Reminder: for leap years, chunksz=183, numchunks=16, timesz=2928
%For non-leap years, chunksz=146, numchunks=20, timesz=2920
%Typically for ERA5: s1=1440, s2=721

%Defaults:
saveloc='/Users/craymond/';
%suffixes={'_ensmem1_loop1';'_ensmem1_loop2';'_ensmem1_loop3';'_ensmem1_loop4'}; %suffixforfilename (one or multiple) to be processed
%correspyrs=[2003]; %also only relevant if running multiple years
deletefilesafter=0;

%Code Block 3 (1 min per 10^9 values)
%---------------
%Finally, Tw values are read back in and then saved Matlab-ally (1 min)
exist suffixes;if ans==1;loopmax=length(suffixes);else;loopmax=1;end

for loop=1:loopmax
    exist suffixes;
    if ans==1 %otherwise, use single suffixforfilename defined elsewhere
        suffixforfilename=suffixes{loop};
        exist correspyrs;
        if ans==1
            y=correspyrs(loop);
            if rem(y,4)==0 %leap year
                chunksz=183;numchunks=16;timesz=2928; %other variables are the same between leap and non-leap years
            else
                chunksz=146;numchunks=20;timesz=2920;
            end
        else %most general situation -- use chunksz, numchunks, timesz already defined
        end
    end 

    didsomething=0;
    if arrdims==2
        tw2m=NaN.*ones(s1,timesz);
        for chunknum=1:numchunks
            indstart=chunksz*chunknum-(chunksz-1);indstop=chunksz*chunknum;
            fname=strcat('/Users/craymond/tw2m_chunk',num2str(chunknum),suffixforfilename,'.nc');
            tw2m(:,indstart:indstop)=ncread(fname,'tw2m');
            save(strcat(saveloc,myfname,suffixforfilename,'.mat'),'tw2m','-v7.3');
        end
        didsomething=1;
    elseif arrdims==3
        tw2m=NaN.*ones(s1,s2,timesz);
        for chunknum=1:numchunks
            indstart=chunksz*chunknum-(chunksz-1);indstop=chunksz*chunknum;
            fname=strcat('/Users/craymond/tw2m_chunk',num2str(chunknum),suffixforfilename,'.nc');
            tw2m(:,:,indstart:indstop)=ncread(fname,'tw2m');
            save(strcat(saveloc,myfname,suffixforfilename,'.mat'),'tw2m','-v7.3');
        end
        didsomething=1;
    elseif arrdims==4
        tw2m=NaN.*ones(s1,s2,s3,timesz);
        for chunknum=1:numchunks
            indstart=chunksz*chunknum-(chunksz-1);indstop=chunksz*chunknum;
            fname=strcat('/Users/craymond/tw2m_chunk',num2str(chunknum),suffixforfilename,'.nc');
            tw2m(:,:,:,indstart:indstop)=ncread(fname,'tw2m');
            save(strcat(saveloc,myfname,suffixforfilename,'.mat'),'tw2m','-v7.3');
        end
        didsomething=1;
    else
        disp('Need to update calctw_matlabpythonhelper_part2.m');return;
    end
    
    
    if deletefilesafter==1 && didsomething==1
        cd /Users/craymond/;
        myfiles=dir(strcat('tw2m_*chunk*',suffixforfilename,'*'));
        for n=1:size(myfiles,1)
            delete(myfiles(n,:).name);
        end
    end
end
%clear suffixes;
clear correspyrs;
%---------------


